const search = document.getElementById('search-books');
const bookList = document.getElementById('book-list');

console.log(search, bookList);
